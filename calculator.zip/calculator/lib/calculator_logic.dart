import 'dart:math';

class CalculatorLogic {
  String _display = '0';
  String _history = '';
  bool _shouldResetDisplay = false;

  String get display => _display;
  String get history => _history;

  void handleButtonPress(String buttonText) {
    switch (buttonText) {
      case 'C':
        _clearAll();
        break;
      case '⌫':
        _backspace();
        break;
      case '=':
        _calculateResult();
        break;
      case '%':
        _calculatePercentage();
        break;
      case '±':
        _toggleSign();
        break;
      case 'sin':
        _handleSin();
        break;
      case 'cos':
        _handleCos();
        break;
      case 'tan':
        _handleTan();
        break;
      case 'log':
        _handleLog();
        break;
      case 'ln':
        _handleLn();
        break;
      case '√':
        _handleSquareRoot();
        break;
      case 'x²':
        _handleSquare();
        break;
      case 'x^y':
        _handlePower();
        break;
      case 'π':
        _handlePi();
        break;
      case '(':
      case ')':
        _handleInput(buttonText);
        break;
      default:
        _handleInput(buttonText);
        break;
    }
  }

  void _clearAll() {
    _display = '0';
    _history = '';
    _shouldResetDisplay = false;
  }

  void _backspace() {
    if (_display.isNotEmpty && _display != '0') {
      if (_display.length == 1) {
        _display = '0';
      } else {
        _display = _display.substring(0, _display.length - 1);
      }
    }
  }

  void _toggleSign() {
    if (_display != '0' && _display != 'Error') {
      if (_display.startsWith('-')) {
        _display = _display.substring(1);
      } else {
        _display = '-$_display';
      }
    }
  }

  void _handleInput(String buttonText) {
    if (_shouldResetDisplay) {
      _display = '';
      _shouldResetDisplay = false;
    }

    if (buttonText == '.' && _display.contains('.')) {
      return;
    }

    if (_display == '0' && buttonText != '.') {
      _display = buttonText;
    } else {
      _display += buttonText;
    }
  }

  void _handleSin() {
    try {
      final value = double.parse(_display);
      final result = sin(value);
      _history = 'sin($value)';
      _display = _formatResult(result);
      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }

  void _handleCos() {
    try {
      final value = double.parse(_display);
      final result = cos(value);
      _history = 'cos($value)';
      _display = _formatResult(result);
      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }

  void _handleTan() {
    try {
      final value = double.parse(_display);
      final result = tan(value);
      _history = 'tan($value)';
      _display = _formatResult(result);
      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }

  void _handleLog() {
    try {
      final value = double.parse(_display);
      if (value <= 0) {
        _display = 'Error';
        return;
      }
      final result = log(value) / ln10;
      _history = 'log($value)';
      _display = _formatResult(result);
      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }

  void _handleLn() {
    try {
      final value = double.parse(_display);
      if (value <= 0) {
        _display = 'Error';
        return;
      }
      final result = log(value);
      _history = 'ln($value)';
      _display = _formatResult(result);
      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }

  void _handleSquareRoot() {
    try {
      final value = double.parse(_display);
      if (value < 0) {
        _display = 'Error';
        return;
      }
      final result = sqrt(value);
      _history = '√($value)';
      _display = _formatResult(result);
      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }

  void _handleSquare() {
    try {
      final value = double.parse(_display);
      final result = value * value;
      _history = '($value)²';
      _display = _formatResult(result);
      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }

  void _handlePower() {
    _handleInput('^');
  }

  void _handlePi() {
    if (_shouldResetDisplay || _display == '0') {
      _display = pi.toString();
    } else {
      _display += pi.toString();
    }
    _shouldResetDisplay = false;
  }

  void _calculatePercentage() {
    try {
      final value = double.parse(_display);
      final result = value / 100;
      _display = _formatResult(result);
      _history = '$value%';
      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }

  String _formatResult(double result) {
    if (result.isInfinite || result.isNaN) {
      return 'Error';
    }

    if (result.abs() < 1e-12) return '0';

    if (result.abs() > 1e12 || (result.abs() < 1e-6 && result != 0)) {
      return result.toStringAsExponential(6);
    }

    final stringValue = result.toString();
    return stringValue.contains('.')
        ? stringValue.replaceAll(RegExp(r'\.?0+$'), '')
        : stringValue;
  }

  void _calculateResult() {
    try {
      _history = _display;
      String expression = _display;

      expression = expression.replaceAll('×', '*');
      expression = expression.replaceAll('÷', '/');

      // Handle power operation
      if (expression.contains('^')) {
        final parts = expression.split('^');
        final base = double.parse(parts[0]);
        final exponent = double.parse(parts[1]);
        final result = pow(base, exponent);
        _display = _formatResult(result.toDouble());
        _shouldResetDisplay = true;
        return;
      }

      // Basic operations
      if (expression.contains('+')) {
        final parts = expression.split('+');
        final result = double.parse(parts[0]) + double.parse(parts[1]);
        _display = _formatResult(result);
      } else if (expression.contains('-')) {
        final parts = expression.split('-');
        final result = double.parse(parts[0]) - double.parse(parts[1]);
        _display = _formatResult(result);
      } else if (expression.contains('*')) {
        final parts = expression.split('*');
        final result = double.parse(parts[0]) * double.parse(parts[1]);
        _display = _formatResult(result);
      } else if (expression.contains('/')) {
        final parts = expression.split('/');
        if (double.parse(parts[1]) == 0) {
          _display = 'Error';
        } else {
          final result = double.parse(parts[0]) / double.parse(parts[1]);
          _display = _formatResult(result);
        }
      }

      _shouldResetDisplay = true;
    } catch (e) {
      _display = 'Error';
      _shouldResetDisplay = true;
    }
  }
}