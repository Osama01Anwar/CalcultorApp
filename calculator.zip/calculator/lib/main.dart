import 'package:flutter/material.dart';

void main() {
  runApp(const ScientificCalculatorApp());
}

class ScientificCalculatorApp extends StatelessWidget {
  const ScientificCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Scientific Calculator',
      theme: ThemeData.light().copyWith(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      darkTheme: ThemeData.dark().copyWith(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const CalculatorHome(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class CalculatorHome extends StatefulWidget {
  const CalculatorHome({super.key});

  @override
  State<CalculatorHome> createState() => _CalculatorHomeState();
}

class _CalculatorHomeState extends State<CalculatorHome> {
  String _display = '0';
  String _history = '';
  bool _isScientific = false;

  void _onButtonPressed(String buttonText) {
    setState(() {
      if (buttonText == 'C') {
        _display = '0';
        _history = '';
      } else if (buttonText == '⌫') {
        if (_display.length > 1) {
          _display = _display.substring(0, _display.length - 1);
        } else {
          _display = '0';
        }
      } else if (_display == '0') {
        _display = buttonText;
      } else {
        _display += buttonText;
      }
    });
  }

  Widget _buildButton(String text, {bool isOperator = false, bool isWide = false, double fontSize = 20}) {
    return Container(
      margin: const EdgeInsets.all(4),
      child: ElevatedButton(
        onPressed: () => _onButtonPressed(text),
        style: ElevatedButton.styleFrom(
          backgroundColor: isOperator ? Colors.orange : Colors.grey[300],
          foregroundColor: isOperator ? Colors.white : Colors.black,
          minimumSize: Size(isWide ? 152 : 72, 72),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: Text(
          text,
          style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scientific Calculator'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(_isScientific ? Icons.science : Icons.calculate),
            onPressed: () => setState(() => _isScientific = !_isScientific),
            tooltip: 'Scientific Mode',
          ),
        ],
      ),
      body: Column(
        children: [
          // Display
          Container(
            padding: const EdgeInsets.all(20),
            alignment: Alignment.centerRight,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  _history,
                  style: const TextStyle(fontSize: 16, color: Colors.grey),
                ),
                Text(
                  _display,
                  style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w300),
                ),
              ],
            ),
          ),

          // Buttons
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(8),
              child: GridView.count(
                crossAxisCount: _isScientific ? 6 : 4,
                childAspectRatio: 1.0,
                children: _isScientific ? [
                  // Scientific mode buttons (6 columns)
                  _buildButton('sin', fontSize: 16), _buildButton('cos', fontSize: 16), _buildButton('tan', fontSize: 16),
                  _buildButton('C', isOperator: true), _buildButton('⌫', isOperator: true), _buildButton('÷', isOperator: true),
                  _buildButton('log', fontSize: 16), _buildButton('ln', fontSize: 16), _buildButton('√', fontSize: 16),
                  _buildButton('7'), _buildButton('8'), _buildButton('9'),
                  _buildButton('x²', fontSize: 16), _buildButton('x^y', fontSize: 16), _buildButton('π', fontSize: 16),
                  _buildButton('4'), _buildButton('5'), _buildButton('6'),
                  _buildButton('(', fontSize: 16), _buildButton(')', fontSize: 16), _buildButton('%', isOperator: true),
                  _buildButton('1'), _buildButton('2'), _buildButton('3'),
                  _buildButton('0', isWide: true), _buildButton('.'), _buildButton('±', fontSize: 16),
                  _buildButton('=', isOperator: true),
                ] : [
                  // Basic mode buttons (4 columns)
                  _buildButton('C', isOperator: true), _buildButton('⌫', isOperator: true),
                  _buildButton('%', isOperator: true), _buildButton('÷', isOperator: true),
                  _buildButton('7'), _buildButton('8'), _buildButton('9'), _buildButton('×', isOperator: true),
                  _buildButton('4'), _buildButton('5'), _buildButton('6'), _buildButton('-', isOperator: true),
                  _buildButton('1'), _buildButton('2'), _buildButton('3'), _buildButton('+', isOperator: true),
                  _buildButton('0', isWide: true), _buildButton('.'), _buildButton('=', isOperator: true),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}