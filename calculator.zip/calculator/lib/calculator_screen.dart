import 'package:flutter/material.dart';
import 'calculator_logic.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  final CalculatorLogic _calculator = CalculatorLogic();
  bool _isScientific = false;

  void _onButtonPressed(String buttonText) {
    setState(() {
      _calculator.handleButtonPress(buttonText);
    });
  }

  Widget _buildButton(
      String text, {
        Color? backgroundColor,
        Color? textColor,
        double? fontSize,
        bool isWide = false,
        bool isAccent = false,
      }) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      margin: const EdgeInsets.all(4),
      child: Material(
        borderRadius: BorderRadius.circular(16),
        elevation: 4,
        shadowColor: Colors.black.withOpacity(0.3),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _onButtonPressed(text),
          child: Container(
            width: isWide ? 152 : 72,
            height: 72,
            decoration: BoxDecoration(
              gradient: isAccent
                  ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colorScheme.primary.withOpacity(0.9),
                  colorScheme.primary,
                ],
              )
                  : null,
              color: isAccent ? null : backgroundColor ?? colorScheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: isAccent
                  ? null
                  : Border.all(
                color: colorScheme.outline.withOpacity(0.1),
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                text,
                style: TextStyle(
                  fontSize: fontSize ?? 20,
                  fontWeight: FontWeight.w500,
                  color: isAccent ? Colors.white : textColor ?? colorScheme.onSurface,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildBasicButtons() {
    final colorScheme = Theme.of(context).colorScheme;

    return [
      // First Row
      _buildButton('C',
        backgroundColor: colorScheme.errorContainer,
        textColor: colorScheme.onErrorContainer,
      ),
      _buildButton('⌫',
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('%',
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('÷', isAccent: true),

      // Second Row
      _buildButton('7'),
      _buildButton('8'),
      _buildButton('9'),
      _buildButton('×', isAccent: true),

      // Third Row
      _buildButton('4'),
      _buildButton('5'),
      _buildButton('6'),
      _buildButton('-', isAccent: true),

      // Fourth Row
      _buildButton('1'),
      _buildButton('2'),
      _buildButton('3'),
      _buildButton('+', isAccent: true),

      // Fifth Row
      _buildButton('0', isWide: true),
      _buildButton('.'),
      _buildButton('=', isAccent: true),
    ];
  }

  List<Widget> _buildScientificButtons() {
    final colorScheme = Theme.of(context).colorScheme;

    return [
      // First Row - Scientific functions
      _buildButton('sin', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('cos', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('tan', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('C',
        backgroundColor: colorScheme.errorContainer,
        textColor: colorScheme.onErrorContainer,
      ),
      _buildButton('⌫',
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('÷', isAccent: true),

      // Second Row - Scientific functions
      _buildButton('log', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('ln', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('√', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('7'),
      _buildButton('8'),
      _buildButton('9'),
      _buildButton('×', isAccent: true),

      // Third Row - Scientific functions
      _buildButton('x²', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('x^y', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('π', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('4'),
      _buildButton('5'),
      _buildButton('6'),
      _buildButton('-', isAccent: true),

      // Fourth Row - Scientific functions
      _buildButton('(', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton(')', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('%',
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('1'),
      _buildButton('2'),
      _buildButton('3'),
      _buildButton('+', isAccent: true),

      // Fifth Row
      _buildButton('0', isWide: true),
      _buildButton('.'),
      _buildButton('±', fontSize: 16,
        backgroundColor: colorScheme.secondaryContainer,
        textColor: colorScheme.onSecondaryContainer,
      ),
      _buildButton('=', isAccent: true),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final isPortrait = MediaQuery.of(context).orientation == Orientation.portrait;

    return Scaffold(
      backgroundColor: colorScheme.background,
      body: SafeArea(
        child: isPortrait ? _buildPortraitLayout() : _buildLandscapeLayout(),
      ),
    );
  }

  Widget _buildPortraitLayout() {
    final colorScheme = Theme.of(context).colorScheme;

    return Column(
      children: [
        // App Bar
        _buildAppBar(),

        // Display
        _buildDisplay(),

        // Buttons Grid
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(16),
            child: GridView.count(
              crossAxisCount: _isScientific ? 6 : 4,
              childAspectRatio: 1.0,
              physics: const NeverScrollableScrollPhysics(),
              children: _isScientific
                  ? _buildScientificButtons()
                  : _buildBasicButtons(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLandscapeLayout() {
    final colorScheme = Theme.of(context).colorScheme;

    return Row(
      children: [
        // Left side - Display and basic buttons
        Expanded(
          flex: 3,
          child: Column(
            children: [
              _buildAppBar(),
              _buildDisplay(),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(16),
                  child: GridView.count(
                    crossAxisCount: 4,
                    childAspectRatio: 1.0,
                    physics: const NeverScrollableScrollPhysics(),
                    children: _buildBasicButtons(),
                  ),
                ),
              ),
            ],
          ),
        ),

        // Right side - Scientific buttons
        Expanded(
          flex: 2,
          child: Container(
            margin: const EdgeInsets.all(16),
            child: GridView.count(
              crossAxisCount: 3,
              childAspectRatio: 1.0,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _buildButton('sin', fontSize: 14),
                _buildButton('cos', fontSize: 14),
                _buildButton('tan', fontSize: 14),
                _buildButton('log', fontSize: 14),
                _buildButton('ln', fontSize: 14),
                _buildButton('√', fontSize: 14),
                _buildButton('x²', fontSize: 14),
                _buildButton('x^y', fontSize: 14),
                _buildButton('π', fontSize: 14),
                _buildButton('(', fontSize: 14),
                _buildButton(')', fontSize: 14),
                _buildButton('±', fontSize: 14),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAppBar() {
    final colorScheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Scientific Calculator',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              color: colorScheme.onBackground,
              letterSpacing: -0.5,
            ),
          ),
          // Scientific Mode Toggle
          Tooltip(
            message: 'Scientific Mode',
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () {
                setState(() {
                  _isScientific = !_isScientific;
                });
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _isScientific
                      ? colorScheme.primary.withOpacity(0.1)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  _isScientific ? Icons.science : Icons.science_outlined,
                  color: _isScientific ? colorScheme.primary : colorScheme.onBackground.withOpacity(0.6),
                  size: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDisplay() {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            colorScheme.surface,
            colorScheme.surface.withOpacity(0.9),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
        border: Border.all(
          color: colorScheme.outline.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            _calculator.history,
            style: TextStyle(
              fontSize: 16,
              color: colorScheme.onSurface.withOpacity(0.6),
              fontWeight: FontWeight.w400,
            ),
            textAlign: TextAlign.end,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 8),
          Text(
            _calculator.display,
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.w300,
              color: colorScheme.onSurface,
              letterSpacing: -1,
            ),
            textAlign: TextAlign.end,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}